// Auto-generated from run.html — keep in sync manually, or regenerate
// with a build step if run.html changes. Embedding as a string avoids
// relying on env.ASSETS.fetch() for the template itself.
export const RUN_HTML_TEMPLATE = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <title>LOGIFUNGE — an esoteric logic-gate programming language IDE</title>
  <meta name="description" content="LOGIFUNGE is a browser-based esoteric programming language built on Befunge-style 2D movement and boolean logic gates (AND, OR, XOR, NAND, NOR, XNOR). Write, step through, and run programs with live text or pixel output — no install required." />
  <meta name="keywords" content="logifunge, esoteric programming language, esolang, befunge, logic gates, boolean logic, online IDE, code playground" />
  <meta name="author" content="LOGIFUNGE" />
  <meta name="theme-color" content="#111111" />
  <link rel="canonical" href="https://logifunge.pages.dev/__VERSION__/" />

  <!-- Open Graph / social embeds -->
  <meta property="og:type" content="website" />
  <meta property="og:title" content="LOGIFUNGE — an esoteric logic-gate programming language IDE" />
  <meta property="og:description" content="A browser-based esoteric language combining Befunge-style 2D movement with boolean logic gates. Write, step, and run code with live text or pixel output." />
  <meta property="og:url" content="https://logifunge.pages.dev/__VERSION__/" />
  <meta property="og:site_name" content="LOGIFUNGE" />
  <meta property="og:image" content="https://logifunge.pages.dev/og-image.png" />
  <meta property="og:image:width" content="1200" />
  <meta property="og:image:height" content="630" />

  <!-- Twitter card -->
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="LOGIFUNGE — an esoteric logic-gate programming language IDE" />
  <meta name="twitter:description" content="A browser-based esoteric language combining Befunge-style 2D movement with boolean logic gates. Write, step, and run code with live text or pixel output." />
  <meta name="twitter:image" content="https://logifunge.pages.dev/og-image.png" />

  <!-- Favicon (inline SVG — no extra file/request needed) -->
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' fill='%23111'/%3E%3Ctext x='50' y='68' font-size='60' font-family='monospace' font-weight='bold' fill='%23fa0' text-anchor='middle'%3E%26gt;%3C/text%3E%3C/svg%3E" />

  <!-- Structured data for search engines -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "LOGIFUNGE",
    "applicationCategory": "DeveloperApplication",
    "operatingSystem": "Any (runs in browser)",
    "description": "LOGIFUNGE is a browser-based esoteric programming language combining Befunge-style 2D movement with boolean logic gates. Includes a code editor, step debugger, and live text/pixel output.",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    }
  }
  </script>

  <link rel="stylesheet" href="/shared/style.css" />
  <link rel="stylesheet" href="/shared/logifunge-ace-theme.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.2/ace.min.js"></script>
  <script src="/shared/mode-logifunge.js"></script>
</head>
<body>

<!-- TOP BAR -->
<div id="top-bar">
  <span style="color:#fa0;font-size:13px;font-weight:bold;letter-spacing:1px">LOGIFUNGE</span>
  <div class="sep"></div>
  <button id="btn-run">▶ Run</button>
  <button id="btn-step">Step</button>
  <button id="btn-clear">Clear Output</button>
  <div class="sep"></div>
  <div id="mode-wrap">
    <button id="mode-text" class="active">Text</button>
    <button id="mode-pixel">Pixel</button>
    <button id="mode-both">Dual</button>
    <button id="mode-stacks">Stacks</button>
  </div>
  <div class="sep"></div>
  <div id="speed-wrap">
    <label for="speed-select">Speed</label>
    <select id="speed-select">
      <option value="1">1/s</option>
      <option value="2">2/s</option>
      <option value="5">5/s</option>
      <option value="10" selected>10/s</option>
      <option value="25">25/s</option>
      <option value="50">50/s</option>
      <option value="100">100/s</option>
      <option value="max">Max</option>
      <option value="turbo">Turbo</option>
    </select>
  </div>
  <div id="dir-wrap">
    <span id="dir-indicator">Dir &gt;</span>
  </div>
  <div id="dim-wrap">
    W <input id="inp-w" type="number" value="32" min="1" max="256" />
    H <input id="inp-h" type="number" value="32" min="1" max="256" />
  </div>
  <div id="max-wrap">
    <label for="max-steps">Max Steps</label>
    <input id="max-steps" type="number" value="1000000" min="1000" step="1000" />
  </div>
  <div id="spacer"></div>
  <span id="status">Ready</span>
  <div class="sep"></div>
  <button id="btn-toggle-highlight">SYNTAX</button>
  <button id="btn-help" onclick="window.open('/docs/__VERSION__/', '_blank', 'noopener')">DOCS</button>
</div>

<!-- BODY -->
<div id="body">

  <!-- EDITOR PANE -->
  <div id="editor-pane">
    <div id="editor-pane-header">Source</div>
    <div id="ace-editor"></div>
    <div id="stack-bar">
      <span style="color:#444;margin-right:4px">Stack</span>
      <span id="stack-vals" style="color:#333">empty</span>
    </div>
  </div>

  <!-- DISPLAY PANE -->
  <div id="display-pane">
    <div id="display-pane-header">Output</div>

    <div id="text-output" style="overflow-y: auto;">
      <div id="text-content"></div>
    </div>

    <div id="pixel-output" class="visible">
      <div id="canvas-wrap">
        <canvas id="pixel-canvas"></canvas>
        <canvas id="grid-overlay"></canvas>
      </div>
    </div>

    <div id="stacks-output" hidden>
      <div id="stacks-toolbar">
        <label for="stack-value-search">Value</label>
        <input id="stack-value-search" type="search" placeholder="search values" autocomplete="off" />
        <label for="stack-index-search">Index</label>
        <input id="stack-index-search" type="search" placeholder="search indexes" autocomplete="off" />
        <span id="stack-search-status"></span>
      </div>
      <div class="stack-view-section">
        <div class="stack-view-header">
          <span>Data Stack</span>
          <input id="stack-range" type="search" placeholder="range 0:10" aria-label="Data stack index range" autocomplete="off" />
          <select id="stack-order" aria-label="Data stack display order">
            <option value="default" selected>Default</option>
            <option value="ascending">Lowest to Highest</option>
            <option value="descending">Highest to Lowest</option>
          </select>
        </div>
        <pre id="stack-view-values">empty</pre>
      </div>
      <div class="stack-view-section">
        <div class="stack-view-header">
          <span>Memory</span>
          <input id="memory-range" type="search" placeholder="range 0:10" aria-label="Memory index range" autocomplete="off" />
          <select id="memory-order" aria-label="Memory display order">
            <option value="default" selected>Default</option>
            <option value="ascending">Lowest to Highest</option>
            <option value="descending">Highest to Lowest</option>
          </select>
        </div>
        <pre id="memory-view-values">empty</pre>
      </div>
    </div>
  </div>
</div>

<script src="/examples/__VERSION__.js"></script>
<script src="/interpreter?v=__VERSION_NUM__"></script>
<script>
// ── ACE EDITOR SETUP ──────────────────────────────────────────
const aceEditor = ace.edit('ace-editor');
aceEditor.setTheme('ace/theme/tomorrow_night');
aceEditor.session.setMode('ace/mode/text');
aceEditor.setOptions({
  fontSize: '13px',
  fontFamily: 'monospace',
  showPrintMargin: false,
  highlightActiveLine: true,
  wrap: false,
  tabSize: 2,
  useSoftTabs: true,
});

// ── STATE ─────────────────────────────────────────────────────
let outputMode = 'text';
let stepInterp = null, stepW = 32, stepH = 32;
let runInterp = null;
let runTimer = null;
let activeCellMarker = null;
let lastStack = [];
let lastMemory = {};
let lastMemoryPointer = 0;

const bundledExamples = window.examples || [];

// ── DOM REFS ──────────────────────────────────────────────────
const textOutput  = document.getElementById('text-output');
const textContent = document.getElementById('text-content');
const pixelOutput = document.getElementById('pixel-output');
const stacksOutput = document.getElementById('stacks-output');
const canvas      = document.getElementById('pixel-canvas');
const gridCanvas  = document.getElementById('grid-overlay');
const statusEl    = document.getElementById('status');
const stackVals   = document.getElementById('stack-vals');
const dimWrap     = document.getElementById('dim-wrap');
const inpW        = document.getElementById('inp-w');
const inpH        = document.getElementById('inp-h');
const btnRun      = document.getElementById('btn-run');
const btnStep     = document.getElementById('btn-step');
const btnClear    = document.getElementById('btn-clear');
const modeBtnText = document.getElementById('mode-text');
const modeBtnPixel= document.getElementById('mode-pixel');
const modeBtnBoth = document.getElementById('mode-both');
const modeBtnStacks = document.getElementById('mode-stacks');
const speedSelect = document.getElementById('speed-select');
const maxStepsInput = document.getElementById('max-steps');
const dirIndicator= document.getElementById('dir-indicator');
const ctx         = canvas.getContext('2d');
const gCtx        = gridCanvas.getContext('2d');
const stackViewValues = document.getElementById('stack-view-values');
const memoryViewValues = document.getElementById('memory-view-values');
const stackValueSearch = document.getElementById('stack-value-search');
const stackIndexSearch = document.getElementById('stack-index-search');
const stackSearchStatus = document.getElementById('stack-search-status');
const stackOrder = document.getElementById('stack-order');
const memoryOrder = document.getElementById('memory-order');
const stackRangeInput = document.getElementById('stack-range');
const memoryRangeInput = document.getElementById('memory-range');
const btnHighlight = document.getElementById('btn-toggle-highlight');
let isHighlightingOn = false;

function toggleHighlighting() {
  isHighlightingOn = !isHighlightingOn;
  
  if (isHighlightingOn) {
    aceEditor.session.setMode('ace/mode/logifunge');
    btnHighlight.style.color = '#fa0'; // Optional: make it gold when on
  } else {
    aceEditor.session.setMode('ace/mode/text');
    btnHighlight.style.color = ''; // Reset color
  }
}

btnHighlight.addEventListener('click', toggleHighlighting);


let stackSearchTimer = null;

// ── MODE ──────────────────────────────────────────────────────
function setMode(m) {
  outputMode = m;
  modeBtnText.classList.toggle('active', m === 'text');
  modeBtnPixel.classList.toggle('active', m === 'pixel');
  modeBtnBoth.classList.toggle('active', m === 'both');
  modeBtnStacks.classList.toggle('active', m === 'stacks');
  textOutput.classList.toggle('visible', m === 'text' || m === 'both');
  pixelOutput.classList.toggle('visible', m === 'pixel' || m === 'both');
  stacksOutput.hidden = m !== 'stacks';
  stacksOutput.classList.toggle('visible', m === 'stacks');
  dimWrap.classList.toggle('hidden', m === 'text' || m === 'stacks');
  if (m === 'stacks') renderStacks();
}
modeBtnText.addEventListener('click', () => setMode('text'));
modeBtnPixel.addEventListener('click', () => setMode('pixel'));
modeBtnBoth.addEventListener('click', () => setMode('both'));
modeBtnStacks.addEventListener('click', () => setMode('stacks'));
function scheduleStackSearch() {
  clearTimeout(stackSearchTimer);
  stackSearchTimer = setTimeout(renderStacks, 120);
}
stackValueSearch.addEventListener('input', scheduleStackSearch);
stackIndexSearch.addEventListener('input', scheduleStackSearch);
stackOrder.addEventListener('change', renderStacks);
memoryOrder.addEventListener('change', renderStacks);
stackRangeInput.addEventListener('input', scheduleStackSearch);
memoryRangeInput.addEventListener('input', scheduleStackSearch);

// ── CANVAS ────────────────────────────────────────────────────
function setupCanvas(w, h) {
  const maxW = pixelOutput.clientWidth  - 24;
  const maxH = pixelOutput.clientHeight - 24;
  const scale = Math.max(1, Math.min(Math.floor(maxW / w), Math.floor(maxH / h)));
  canvas.width = w; canvas.height = h;
  canvas.style.width  = (w * scale) + 'px';
  canvas.style.height = (h * scale) + 'px';
  gridCanvas.width  = w * scale; gridCanvas.height = h * scale;
  gridCanvas.style.width  = (w * scale) + 'px';
  gridCanvas.style.height = (h * scale) + 'px';
  ctx.fillStyle = '#111';
  ctx.fillRect(0, 0, w, h);
  gCtx.clearRect(0, 0, w * scale, h * scale);
  gCtx.strokeStyle = '#0f8';
  gCtx.lineWidth = 0.5;
  for (let x = 0; x <= w; x++) { gCtx.beginPath(); gCtx.moveTo(x*scale,0); gCtx.lineTo(x*scale,h*scale); gCtx.stroke(); }
  for (let y = 0; y <= h; y++) { gCtx.beginPath(); gCtx.moveTo(0,y*scale); gCtx.lineTo(w*scale,y*scale); gCtx.stroke(); }
  return scale;
}

function drawPixels(pixels, w, h) {
  const idata = ctx.createImageData(w, h);
  for (let i = 0; i < idata.data.length; i += 4) { idata.data[i]=17; idata.data[i+1]=17; idata.data[i+2]=17; idata.data[i+3]=255; }
  for (const p of pixels) {
    if (p.x < 0 || p.x >= w || p.y < 0 || p.y >= h) continue;
    const idx = (p.y * w + p.x) * 4;
    if (p.on) {
      const v = Math.min(255, Math.max(0, p.value));
      idata.data[idx]   = v > 1 ? 0   : 255;
      idata.data[idx+1] = v > 1 ? v   : 170;
      idata.data[idx+2] = v > 1 ? 136 : 0;
      idata.data[idx+3] = 255;
    } else {
      idata.data[idx]=20; idata.data[idx+1]=24; idata.data[idx+2]=36; idata.data[idx+3]=255;
    }
  }
  ctx.putImageData(idata, 0, 0);
}

// ── STATUS / STACK ────────────────────────────────────────────
function setStatus(msg, cls) {
  statusEl.textContent = msg;
  statusEl.className = cls || '';
}

function setDirectionLabel(dir) {
  const arrow = dir && dir.x === 1 ? '>' : dir && dir.x === -1 ? '<' : dir && dir.y === 1 ? 'v' : '^';
  dirIndicator.textContent = \`DIR \${arrow || '>'}\`;
}

function clearActiveCellHighlight() {
  if (activeCellMarker !== null) {
    aceEditor.session.removeMarker(activeCellMarker);
    activeCellMarker = null;
  }
  aceEditor.selection.clearSelection();
}

function highlightActiveCell(interp) {
  clearActiveCellHighlight();
  if (!interp || !interp.ip) return;
  const { x, y } = interp.ip;
  if (y < 0 || x < 0) return;
  const row = Math.max(0, y);
  const col = Math.max(0, x);
  const range = new ace.Range(row, col, row, Math.min(aceEditor.session.getLine(row).length, col + 1));
  activeCellMarker = aceEditor.session.addMarker(range, 'ace_active-cell', 'text', false);
  aceEditor.moveCursorTo(row, col);
  aceEditor.clearSelection();
  aceEditor.renderer.scrollCursorIntoView();
  setDirectionLabel(interp.dir);
}

function showStack(stack) {
  if (!stack || stack.length === 0) {
    stackVals.innerHTML = '<span style="color:#333">empty</span>';
  } else {
    const previewLimit = 200;
    const preview = stack.slice(-previewLimit);
    const count = stack.length > previewLimit
      ? \`<span style="color:#666">\${stack.length} values: </span>\`
      : '';
    stackVals.innerHTML = count + preview.map(v => \`<span class="val">\${v}</span>\`).join(' ');
  }
}


function showStacks(stack, memory, memoryPointer) {
  lastStack = stack || [];
  lastMemory = memory || {};
  lastMemoryPointer = memoryPointer ?? 0;
  if (outputMode !== 'stacks') return;
  renderStacks();
}

function parseIndexRange(query, maxIndex) {
  const match = query.match(/^(-?\\d*)\\s*:\\s*(-?\\d*)$/);
  if (!match) return null;
  const start = match[1] === '' ? 0 : Number(match[1]);
  const end = match[2] === '' ? maxIndex : Number(match[2]);
  const clampedStart = Math.max(0, Math.min(maxIndex, start));
  const clampedEnd = Math.max(0, Math.min(maxIndex, end));
  return {
    start: Math.min(clampedStart, clampedEnd),
    end: Math.max(clampedStart, clampedEnd),
  };
}

function renderStacks() {
  const valueQuery = stackValueSearch.value.trim().toLowerCase();
  const indexQuery = stackIndexSearch.value.trim().toLowerCase();
  const stackRangeQuery = stackRangeInput.value.trim().toLowerCase();
  const memoryRangeQuery = memoryRangeInput.value.trim().toLowerCase();
  const hasQuery = valueQuery || indexQuery || stackRangeQuery || memoryRangeQuery;
  const maxResults = 5000;
  function orderedIndexes(indexes, order) {
    if (order === 'ascending') return indexes.slice(0, maxResults);
    if (order === 'descending') return indexes.slice(-maxResults).reverse();
    const lower = indexes.slice(0, Math.ceil(maxResults / 2)).reverse();
    const upper = indexes.slice(-Math.floor(maxResults / 2)).reverse();
    return [...upper, ...lower.filter(index => !upper.includes(index))];
  }

  function matchingIndexes(indexes, valueForIndex, rangeQuery, maxIndex) {
    if (!hasQuery) return indexes;
    const range = parseIndexRange(rangeQuery, maxIndex);
    return indexes.filter(index => {
      const value = String(valueForIndex(index)).toLowerCase();
      if (range && (index < range.start || index > range.end)) return false;
      return (!valueQuery || value.includes(valueQuery)) &&
        (!indexQuery || String(index).includes(indexQuery));
    });
  }

  const stackIndexes = matchingIndexes(
    Array.from({ length: lastStack.length }, (_, index) => index),
    index => lastStack[index],
    stackRangeQuery,
    Math.max(0, lastStack.length - 1)
  );
  const orderedStackIndexes = orderedIndexes(stackIndexes, stackOrder.value);
  const stackMatches = stackIndexes.length;
  const stackLines = orderedStackIndexes.map(index => \`\${index}: \${lastStack[index]}\`);

  const memoryIndexes = Object.keys(lastMemory).sort((a, b) => Number(a) - Number(b));
  const memoryMaxIndex = memoryIndexes.length ? Number(memoryIndexes[memoryIndexes.length - 1]) : 0;
  const matchingMemoryIndexes = matchingIndexes(memoryIndexes, index => lastMemory[index], memoryRangeQuery, memoryMaxIndex);
  const orderedMemoryIndexes = orderedIndexes(matchingMemoryIndexes, memoryOrder.value);
  const memoryMatches = matchingMemoryIndexes.length;
  const memoryLines = orderedMemoryIndexes.map(index => \`\${Number(index) === lastMemoryPointer ? '* ' : '  '}\${index}: \${lastMemory[index]}\`);
  const stackTruncated = stackMatches > maxResults;
  const memoryTruncated = memoryMatches > maxResults;
  stackViewValues.textContent = stackLines.length ? stackLines.join('\\n') : 'empty';
  memoryViewValues.textContent = memoryLines.length ? memoryLines.join('\\n') : 'empty';
  stackSearchStatus.textContent = \`\${stackMatches} stack / \${memoryMatches} memory match\${stackMatches + memoryMatches === 1 ? '' : 'es'}\${stackTruncated || memoryTruncated ? ' (showing first 5,000 per list)' : ''}\`;
}
// ── TURBO WORKER ─────────────────────────────────────────────
let turboWorker = null;
let turboWorkerBusy = false;

function getTurboWorker() {
  if (turboWorker) return turboWorker;
  const workerSrc = \`
    importScripts(\${JSON.stringify(new URL('/interpreter?v=__VERSION_NUM__', location.origin).href)});
    self.onmessage = function(e) {
      const { code, w, h, maxSteps } = e.data;
      const interp = new BefungeLogicInterpreter(code, w, h, maxSteps);
      const result = interp.run();
      const pixelBuf = new Uint32Array(result.pixels.length * 3);
      for (let i = 0; i < result.pixels.length; i++) {
        const p = result.pixels[i];
        pixelBuf[i * 3]     = p.x;
        pixelBuf[i * 3 + 1] = p.y;
        pixelBuf[i * 3 + 2] = p.on ? 1 : 0;
      }
      self.postMessage(
        { textOutput: result.textOutput, pixelBuf, steps: result.steps,
          error: result.error, stack: result.stack, memory: result.memory,
          memoryPointer: result.memoryPointer },
        [pixelBuf.buffer]
      );
    };
  \`;
  const blob = new Blob([workerSrc], { type: 'application/javascript' });
  const url = URL.createObjectURL(blob);
  turboWorker = new Worker(url);
  URL.revokeObjectURL(url);
  return turboWorker;
}

function isHighSpeed() {
  const v = speedSelect.value;
  return v === 'max' || v === 'turbo' || parseInt(v, 10) >= 25;
}

// ── RUN ───────────────────────────────────────────────────────
function getStepDelayMs() {
  const value = speedSelect.value;
  if (value === 'max' || value === 'turbo') return 0;
  return Math.max(0, 1000 / parseInt(value, 10));
}

function getChunkSize() {
  return speedSelect.value === 'max' ? 100 : 1;
}

function getMaxSteps() {
  return Math.max(1000, parseInt(maxStepsInput.value) || 1000000);
}

function stopAutoRun(terminateWorker = false) {
  if (runTimer) {
    clearTimeout(runTimer);
    runTimer = null;
  }
  if (turboWorkerBusy) {
    if (terminateWorker && turboWorker) {
      turboWorker.terminate();
      turboWorker = null;
    }
    turboWorkerBusy = false;
  }
  if (isHighSpeed()) clearActiveCellHighlight();
  btnRun.classList.remove('running');
  btnRun.textContent = '▶ Run';
}

function updateDisplay(interp, w, h) {
  const text = interp.output.trimEnd();
  textContent.textContent = text || '— no text output (use . to print) —';
  if (outputMode === 'text' || outputMode === 'both') textContent.style.color = text ? '#0f8' : '#444';
  setupCanvas(w, h);
  if (interp.pixels.length) drawPixels(interp.pixels, w, h);
  showStack(interp.stack);
  showStacks(interp.stack, interp.memory, interp.memoryPointer);
  if (!isHighSpeed()) {
    highlightActiveCell(interp);
  }
}

function run() {
  if (runTimer || turboWorkerBusy) {
    stopAutoRun(true);
    setStatus('Run Stopped');
    return;
  }

  const code = aceEditor.getValue();
  if (!code.trim()) { setStatus('No Code'); return; }
  const execCode = code;
  const w = Math.max(1, Math.min(256, parseInt(inpW.value) || 32));
  const h = Math.max(1, Math.min(256, parseInt(inpH.value) || 32));

  setStatus('Running…');
  btnRun.classList.add('running');
  btnRun.textContent = '■ Stop';

  if (speedSelect.value === 'turbo') {
    const worker = getTurboWorker();
    turboWorkerBusy = true;
    worker.onmessage = (e) => {
      turboWorkerBusy = false;
      const { textOutput, pixelBuf, steps, error, stack, memory, memoryPointer } = e.data;
      const pixels = [];
      for (let i = 0; i < pixelBuf.length; i += 3) {
        const on = pixelBuf[i + 2] !== 0;
        pixels.push({ x: pixelBuf[i], y: pixelBuf[i + 1], on, value: on ? 1 : 0 });
      }
      const text = textOutput;
      textContent.textContent = text || '— no text output (use . to print) —';
      if (outputMode === 'text' || outputMode === 'both') textContent.style.color = text ? '#0f8' : '#444';
      setupCanvas(w, h);
      if (pixels.length) drawPixels(pixels, w, h);
      showStack(stack);
      showStacks(stack, memory, memoryPointer);
      clearActiveCellHighlight();
      btnRun.classList.remove('running');
      btnRun.textContent = '▶ Run';
      if (error) { setStatus(\`⚠ \${error}\`, 'err'); } 
      else { setStatus(\`Done — \${steps} steps\`, 'ok'); }
    };
    worker.onerror = (e) => {
      turboWorkerBusy = false;
      turboWorker = null;
      btnRun.classList.remove('running');
      btnRun.textContent = '▶ Run';
      setStatus('Worker Error: ' + e.message, 'err');
    };
    setupCanvas(w, h);
    worker.postMessage({ code: execCode, w, h, maxSteps: getMaxSteps() });
    return;
  }

  runInterp = new BefungeLogicInterpreter(execCode, w, h, getMaxSteps());
  runInterp.running = true;
  updateDisplay(runInterp, w, h);

  const tick = () => {
    if (!runInterp || !runInterp.running) { stopAutoRun(); return; }
    try {
      const limit = getMaxSteps();
      if (runInterp.maxSteps !== limit) runInterp.maxSteps = limit;
      let cont = true;
      const chunkSize = getChunkSize();
      for (let i = 0; i < chunkSize; i++) {
        if (!runInterp.running) break;
        if (runInterp.steps >= runInterp.maxSteps) {
          runInterp.error = \`Step limit reached\`;
          updateDisplay(runInterp, w, h);
          setStatus(\`⚠ \${runInterp.error}\`, 'err');
          stopAutoRun();
          return;
        }
        cont = runInterp._step();
        if (cont) runInterp.steps++;
        if (runInterp.error) {
          updateDisplay(runInterp, w, h);
          setStatus(\`⚠ \${runInterp.error}\`, 'err');
          stopAutoRun();
          return;
        }
        if (!cont || !runInterp.running) break;
      }
      updateDisplay(runInterp, w, h);
      if (!cont || !runInterp.running) {
        setStatus(\`Done — \${runInterp.steps} steps\`, 'ok');
        stopAutoRun();
        return;
      }
      setStatus(\`Running… \${runInterp.steps} steps\`, 'ok');
      const delay = getStepDelayMs();
      runTimer = setTimeout(tick, delay);
    } catch (e) {
      setStatus('Error: ' + e.message, 'err');
      stopAutoRun();
    }
  };
  tick();
}

// ── STEP ──────────────────────────────────────────────────────
function stepOnce() {
  const code = aceEditor.getValue();
  if (!code.trim()) { setStatus('No Code'); return; }
  stepW = Math.max(1, Math.min(256, parseInt(inpW.value) || 32));
  stepH = Math.max(1, Math.min(256, parseInt(inpH.value) || 32));
  const shouldResetStepInterp = !stepInterp || !stepInterp.running ||
    stepInterp.sourceCode !== code ||
    stepInterp.pixelWidth !== stepW ||
    stepInterp.pixelHeight !== stepH;
  if (shouldResetStepInterp) {
    stepInterp = new BefungeLogicInterpreter(code, stepW, stepH, getMaxSteps());
    stepInterp.running = true;
    setupCanvas(stepW, stepH);
    setStatus('Step Mode');
  }
  if (!stepInterp.running) { setStatus('Done', 'ok'); return; }
  const cont = stepInterp._step();
  if (cont) stepInterp.steps++;
  updateDisplay(stepInterp, stepW, stepH);
  highlightActiveCell(stepInterp);
  setStatus(\`Step \${stepInterp.steps} — IP(\${stepInterp.ip.x},\${stepInterp.ip.y})\`);
  if (!cont || !stepInterp.running) { setStatus(\`Done — \${stepInterp.steps} steps\`, 'ok'); stepInterp = null; }
}

// ── CLEAR OUTPUT ─────────────────────────────────────────────
function clearOutput() {
  if (outputMode === 'text' || outputMode === 'both') {
    textContent.textContent = '';
  }
  if (outputMode === 'pixel' || outputMode === 'both') {
    setupCanvas(parseInt(inpW.value)||32, parseInt(inpH.value)||32);
  }
  if (outputMode === 'stacks') showStacks([], {}, 0);
  setStatus('Output Cleared');
}

// ── KEYBOARD ──────────────────────────────────────────────────
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); run(); }
});

aceEditor.commands.addCommand({
  name: 'run',
  bindKey: { win: 'Ctrl-Enter', mac: 'Command-Enter' },
  exec: run,
});

// ── WIRE BUTTONS ──────────────────────────────────────────────
btnRun.addEventListener('click', run);
btnStep.addEventListener('click', stepOnce);
btnClear.addEventListener('click', clearOutput);
inpW.addEventListener('change', () => setupCanvas(parseInt(inpW.value)||32, parseInt(inpH.value)||32));
inpH.addEventListener('change', () => setupCanvas(parseInt(inpW.value)||32, parseInt(inpH.value)||32));

// ── INIT ──────────────────────────────────────────────────────
setMode('text');
setupCanvas(32, 32);
aceEditor.setValue(bundledExamples[0]?.code || \`0 0 & . 0 1 & . 1 0 & . 1 1 & . %\`, -1);
setDirectionLabel({ x: 1, y: 0 });
clearActiveCellHighlight();
</script>
</body>
</html>`;
